//
//  ViewController.swift
//  FinalProject
//
//  Created by user196527 on 8/13/21.
//

import UIKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate, UITableViewDataSource,UITableViewDelegate{
    var locationManager: CLLocationManager?
    var initializeLocation: CLLocation!
    var saveData = ""
    var visits = [String]()
    
    @IBOutlet weak var tableView: UITableView!

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return visits.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell=tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.numberOfLines = 2
        cell.textLabel?.text=visits[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return .delete
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            tableView.beginUpdates()
            visits.remove(at: indexPath.row)
            UserDefaults.standard.set(visits, forKey: "saveData")
            tableView.deleteRows(at: [indexPath], with:.fade)
            tableView.endUpdates()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager = CLLocationManager()
        locationManager?.delegate = self
        locationManager?.requestWhenInUseAuthorization()
        locationManager?.startUpdatingLocation()
        if let data = UserDefaults.standard.object(forKey: "saveData") as? [String]
        {
            visits=data
        }
        
        // Do any additional setup after loading the view.
    }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        if manager.authorizationStatus == .authorizedAlways{
            print("Authenticate always")
        }else if manager.authorizationStatus == .authorizedWhenInUse{
            print("Authenticate while using app")
        }else{
            print("Authentication Denied")
        }
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.first else {
            return
        }
        


        saveData = "\(location.coordinate.latitude) \(location.coordinate.longitude) \(location.timestamp)"
        locationManager?.stopUpdatingLocation()
        visits.append(saveData)
        UserDefaults.standard.set(visits, forKey: "saveData")
        tableView.reloadData()
    }
    
}

